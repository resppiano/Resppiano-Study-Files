# AWS-Associate-CSA-Study-Materials
This is a repository for my Amazon Web Services Cloud Solution Architect - Associate Level certification exam.
