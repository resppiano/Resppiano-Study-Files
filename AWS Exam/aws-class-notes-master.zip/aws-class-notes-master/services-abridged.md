# These are the services you'll actually need to know for the exam

subtitle of this lecture is "don't freak out" because there are so many services. Focusing on which services we actually need to learn since there are so damn many

## Solutions Architect Associate

Very broad, know a lot of services but you don't need to know the details.

* Global infrastructure
* Compute
* Storage
* Databases
* Migration
* Networking and Content Delivery
* Management tools
* Analytics
* Security and Identity and Compliance
* Application Integration
* Desktop and App Streaming

guy says you can learn s3 dynamodb application integration and analytics in addition to solutions architect and you can go back and get developer easily. Extra hour and a half.

VPCs are the most important part of all of the exams. Most important thing to know.