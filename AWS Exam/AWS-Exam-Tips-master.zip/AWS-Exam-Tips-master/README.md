# AWS-Exam-Tips
As an addon to my article where I explain how I passed 3 exams in 26 days here are my actual notes that I used to pass AWS Cloud Practitioner , AWS Solutions Architect , AWS Developer Associate exams.

You can read my article with my exam tips at https://medium.com/@ozdemircili/how-i-passed-3-aws-certifications-in-26-days-without-hands-on-experience-and-saved-24-000-8b2fec392db0
